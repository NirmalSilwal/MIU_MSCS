package service;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @GetMapping("/phone")
    public String getPhone() {
        System.out.println("fetching phone number from service B");
        return "123-456-7890";
    }
}

