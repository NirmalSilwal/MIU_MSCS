package service;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {

    @GetMapping(path = "/salary")
    public String getSalaryOfEmployee() {
        System.out.println("fetching salary from C service...");
        return "$1000";
    }
}
