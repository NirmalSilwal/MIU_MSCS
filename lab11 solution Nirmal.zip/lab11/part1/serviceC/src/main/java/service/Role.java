package service;

public enum Role {
    CUSTOMER, EMPLOYEE, MANAGER
}
