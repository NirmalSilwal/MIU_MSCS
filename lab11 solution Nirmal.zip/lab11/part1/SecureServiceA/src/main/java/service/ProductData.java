package service;

import lombok.*;
import org.springframework.stereotype.Component;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductData {
    public String id;
    public String name;
    public double price;
    public String description;
}
