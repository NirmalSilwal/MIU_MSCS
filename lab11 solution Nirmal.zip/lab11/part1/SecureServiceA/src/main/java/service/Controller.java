package service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.OAuth2RestTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controller {
    @Autowired
    private OAuth2RestTemplate oAuth2RestTemplate;

    // In A you can call productdata that is accessible by all customers, employees and managers
    @GetMapping("/product")
    public ProductData getProductDetails() {
        return new ProductData("100", "Nivea", 11.5, "Soft body mosturizer");
    }

    // In A you can call employee contact data that is accessible only by employees and managers. A will
    //call B to get the actual employee contact data.
    @GetMapping("/phone")
    public String getPhone() {
        return oAuth2RestTemplate.getForObject("http://localhost:8091/phone", String.class);
    }

    // In A you can call salary data that is accessible only by managers. A will call C to get the actual salary
    //data.
    @GetMapping("/salary")
    public String getSalary() {
        return oAuth2RestTemplate.getForObject("http://localhost:8092/salary", String.class);
    }
}

