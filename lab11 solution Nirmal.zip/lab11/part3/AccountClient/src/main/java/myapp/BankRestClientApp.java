package myapp;

import domains.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;

@SpringBootApplication
public class BankRestClientApp implements CommandLineRunner {
    @Autowired
    private RestOperations restTemplate;

    @Bean
    RestOperations restTemplate() {
        return new RestTemplate();
    }

    public static void main(String[] args) {
        SpringApplication.run(BankRestClientApp.class, args);
    }

    @Override
    public void run(String... args) throws Exception {

        String savingAccount = "http://localhost:8082/savingAccount";
        String checkingAccount = "http://localhost:8081/checkingAccount";

        restTemplate.postForLocation(checkingAccount + "/", new CheckingAccount("100", "Nirmal", 83462));
        restTemplate.postForLocation(savingAccount + "/", new SavingAccount("200", "Rajiv", 234523));

        restTemplate.postForLocation(checkingAccount + "/deposit", new DepositInfo("101", 4566));
        restTemplate.postForLocation(savingAccount + "/deposit", new DepositInfo("102", 23422));
        restTemplate.postForLocation(savingAccount + "/deposit", new DepositInfo("103", 94842));

        restTemplate.postForLocation(checkingAccount + "/withdraw", new WithDrawInfo("1000", 12341));
        restTemplate.postForLocation(savingAccount + "/withdraw", new WithDrawInfo("2000", 3242));
        restTemplate.postForLocation(savingAccount + "/withdraw", new WithDrawInfo("3000", 23425));

        restTemplate.postForLocation(checkingAccount + "/transfer", new TransferInfo(523200, "2", "50"));
        restTemplate.postForLocation(savingAccount + "/transfer", new TransferInfo(32401, "2", "51"));
        restTemplate.postForLocation(savingAccount + "/transfer", new TransferInfo(34032, "2", "52"));
    }
}
