package domains;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TransferInfo {
    private int amount;
    private String savingAccountId;
    private String checkingAccountId;
}