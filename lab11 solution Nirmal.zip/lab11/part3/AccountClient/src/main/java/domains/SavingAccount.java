package domains;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SavingAccount {
    private String id;
    private String name;
    private double balance;
}
