package domains;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class DepositInfo {
    private String accountId;
    private double amount;
}