package com.example.checkingaccount.impls;

import com.example.checkingaccount.CheckingAccountService;
import com.example.checkingaccount.JmsService;
import com.example.checkingaccount.model.CheckingAccount;
import com.example.checkingaccount.model.DepositInfo;
import com.example.checkingaccount.model.TransferInfo;
import com.example.checkingaccount.model.WithDrawInfo;
import com.example.checkingaccount.repo.CheckingAccountRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class CheckingAccountServiceImpl implements CheckingAccountService {

    private final JmsService jmsService;
    private final CheckingAccountRepository checkingAccountRepo;

    public CheckingAccountServiceImpl(CheckingAccountRepository checkingAccountRepo, JmsService jmsService) {
        this.checkingAccountRepo = checkingAccountRepo;
        this.jmsService = jmsService;
    }

    @Override
    public List<CheckingAccount> getAll() {
        return checkingAccountRepo.findAll();
    }

    private CheckingAccount getAccountById(String accountId) {
        Optional<CheckingAccount> account = checkingAccountRepo.findById(accountId);
        if (account.isEmpty()) throw new RuntimeException("Account with given id not found");
        return account.get();
    }

    @Override
    public CheckingAccount save(CheckingAccount checkingAccount) {
        return checkingAccountRepo.save(checkingAccount);
    }

    @Override
    public CheckingAccount deposit(DepositInfo depositInfo) {
        CheckingAccount account = getAccountById(depositInfo.getAccountId());
        account.setBalance(account.getBalance() + depositInfo.getAmount());
        return checkingAccountRepo.save(account);
    }

    @Override
    public CheckingAccount withdraw(WithDrawInfo withDrawInfo) {
        CheckingAccount account = getAccountById(withDrawInfo.getAccountId());
        if (withDrawInfo.getAmount() > account.getBalance()) throw new RuntimeException("In sufficient balance");
        account.setBalance(account.getBalance() - withDrawInfo.getAmount());
        return checkingAccountRepo.save(account);
    }

    @Override
    public void transferToSavingAccount(TransferInfo transferInfo) {
        jmsService.sendMessage(transferInfo);
        withdraw(new WithDrawInfo(transferInfo.getCheckingAccountId(), transferInfo.getAmount()));
    }
}
