package com.example.checkingaccount.impls;

import com.example.checkingaccount.JmsService;
import com.example.checkingaccount.model.TransferInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;
import org.apache.activemq.artemis.jms.client.ActiveMQQueue;


@Service
public class ActiveMqServiceImpl implements JmsService {

    private final ActiveMQQueue queue;
    private final JmsTemplate jmsTemplate;

    public ActiveMqServiceImpl(JmsTemplate jmsTemplate, ActiveMQQueue queue) {
        this.jmsTemplate = jmsTemplate;
        this.queue = queue;
    }

    @Override
    public void sendMessage(TransferInfo transferInfo) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            String productAsJson = mapper.writeValueAsString(transferInfo);
            jmsTemplate.convertAndSend(queue, productAsJson);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
    }
}
