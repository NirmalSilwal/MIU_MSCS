package com.example.checkingaccount.repo;

import com.example.checkingaccount.model.CheckingAccount;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CheckingAccountRepository extends MongoRepository<CheckingAccount , String> {
}
