package com.example.checkingaccount.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class TransferInfo {
    private String checkingAccountId;
    private String savingAccountId;
    private double amount;
}
