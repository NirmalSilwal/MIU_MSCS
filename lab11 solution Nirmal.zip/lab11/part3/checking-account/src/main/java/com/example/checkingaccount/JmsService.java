package com.example.checkingaccount;

import com.example.checkingaccount.model.TransferInfo;

public interface JmsService {
    void sendMessage(TransferInfo transferInfo);
}
