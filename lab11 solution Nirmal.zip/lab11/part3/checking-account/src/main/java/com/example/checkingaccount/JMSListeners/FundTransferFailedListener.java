package com.example.checkingaccount.JMSListeners;

import com.example.checkingaccount.CheckingAccountService;
import com.example.checkingaccount.model.DepositInfo;
import com.example.checkingaccount.model.TransferInfo;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;


@Component
public class FundTransferFailedListener {

    private final CheckingAccountService checkingAccountService;

    public FundTransferFailedListener(CheckingAccountService checkingAccountService) {
        this.checkingAccountService = checkingAccountService;
    }

    @JmsListener(destination = "saving-account-transfer-fail-queue")
    public void fundTransfer(final String message) throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();

        TransferInfo transferInfo = objectMapper.readValue(message, TransferInfo.class);

        System.out.println("****** " + transferInfo.getCheckingAccountId() + " **** "
                + transferInfo.getSavingAccountId() + " ***" + transferInfo.getAmount());

        checkingAccountService.deposit(new DepositInfo(
                transferInfo.getCheckingAccountId(), transferInfo.getAmount()));
    }
}
