package com.example.checkingaccount.controller;

import com.example.checkingaccount.CheckingAccountService;
import com.example.checkingaccount.model.CheckingAccount;
import com.example.checkingaccount.model.DepositInfo;
import com.example.checkingaccount.model.TransferInfo;
import com.example.checkingaccount.model.WithDrawInfo;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("checking-accounts")
public class CheckingController {
    private final CheckingAccountService checkingAccountService;

    public CheckingController(CheckingAccountService checkingAccountService) {
        this.checkingAccountService = checkingAccountService;
    }

    @GetMapping
    public List<CheckingAccount> getAll() {
        return checkingAccountService.getAll();
    }

    @PostMapping
    public CheckingAccount create(@RequestBody CheckingAccount checkingAccount) {
        return checkingAccountService.save(checkingAccount);
    }

    @PostMapping("deposit")
    public CheckingAccount deposit(@RequestBody DepositInfo depositInfo) {
        return checkingAccountService.deposit(depositInfo);
    }

    @PostMapping("withdraw")
    public CheckingAccount withdraw(@RequestBody WithDrawInfo withDrawInfo) {
        return checkingAccountService.withdraw(withDrawInfo);
    }

    @PostMapping("transfer")
    public void transferToSavingAcc(@RequestBody TransferInfo transferInfo) {
        checkingAccountService.transferToSavingAccount(transferInfo);
    }
}
