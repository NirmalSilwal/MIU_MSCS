package com.example.checkingaccount.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;


@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Document
public class CheckingAccount {
    @Id
    private String id;
    private String name;
    private double balance;
}
