package com.example.checkingaccount;

import com.example.checkingaccount.model.CheckingAccount;
import com.example.checkingaccount.model.DepositInfo;
import com.example.checkingaccount.model.TransferInfo;
import com.example.checkingaccount.model.WithDrawInfo;

import java.util.List;

public interface CheckingAccountService {
    List<CheckingAccount> getAll();

    CheckingAccount save(CheckingAccount checkingAccount);

    CheckingAccount deposit(DepositInfo depositInfo);

    CheckingAccount withdraw(WithDrawInfo withDrawInfo);

    void transferToSavingAccount(TransferInfo transferInfo);
}
