package com.example.checkingaccount.model;


import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class DepositInfo {
    private String accountId;
    private double amount;
}
