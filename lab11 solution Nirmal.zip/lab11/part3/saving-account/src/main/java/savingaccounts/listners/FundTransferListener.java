package savingaccounts.listners;

import savingaccounts.JmsService;
import savingaccounts.model.SavingAccount;
import savingaccounts.model.TransferInfo;
import savingaccounts.repository.SavingAccountRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.jms.annotation.JmsListener;
import org.springframework.stereotype.Component;

import java.util.Optional;

@Component
public class FundTransferListener {
    private final JmsService jmsService;
    private final SavingAccountRepository savingAccountRepo;

    public FundTransferListener(SavingAccountRepository savingAccountRepo, JmsService jmsService) {
        this.savingAccountRepo = savingAccountRepo;
        this.jmsService = jmsService;
    }

    @JmsListener(destination = "saving-account-transfer-queue")
    public void fundTransfer(final String message) throws JsonProcessingException {

        ObjectMapper objectMapper = new ObjectMapper();
        TransferInfo transferInfo = objectMapper.readValue(message, TransferInfo.class);

        System.out.println(transferInfo);

        Optional<SavingAccount> account = savingAccountRepo.findById(transferInfo.getSavingAccountId());

        if (account.isEmpty())
            sendErrorMessage(transferInfo);

        account.get().setBalance(account.get().getBalance() + transferInfo.getAmount());
        savingAccountRepo.save(account.get());
    }

    public void sendErrorMessage(TransferInfo transferInfo) {
        jmsService.sendMessage(transferInfo);
    }
}
