package savingaccounts.model;

import lombok.*;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class WithDrawInfo {
    private String accountId;
    private double amount;
}
