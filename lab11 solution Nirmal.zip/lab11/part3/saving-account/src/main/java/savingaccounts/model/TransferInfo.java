package savingaccounts.model;

import lombok.*;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class TransferInfo {
    private String checkingAccountId;
    private String savingAccountId;
    private double amount;
}
