package savingaccounts;

import savingaccounts.model.DepositInfo;
import savingaccounts.model.SavingAccount;
import savingaccounts.model.WithDrawInfo;

import java.util.List;

public interface SavingAccountService {

    List<SavingAccount> getAll();
    SavingAccount deposit(DepositInfo depositInfo);
    SavingAccount save(SavingAccount checkingAccount);
    SavingAccount withdraw(WithDrawInfo withDrawInfo);
}
