package savingaccounts;

import savingaccounts.model.TransferInfo;

public interface JmsService {
    void sendMessage(TransferInfo transferInfo);
}
