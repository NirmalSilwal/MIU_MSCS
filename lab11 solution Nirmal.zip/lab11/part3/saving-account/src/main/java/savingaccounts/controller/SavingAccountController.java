package savingaccounts.controller;

import savingaccounts.SavingAccountService;
import savingaccounts.model.DepositInfo;
import savingaccounts.model.SavingAccount;
import savingaccounts.model.WithDrawInfo;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("saving-accounts")
public class SavingAccountController {
    private final SavingAccountService savingAccountService;

    public SavingAccountController(SavingAccountService savingAccountService) {
        this.savingAccountService = savingAccountService;
    }

    @GetMapping
    public List<SavingAccount> getAll() {
        return savingAccountService.getAll();
    }

    @PostMapping("withdraw")
    public SavingAccount withdraw(@RequestBody WithDrawInfo withDrawInfo) {
        return savingAccountService.withdraw(withDrawInfo);
    }

    @PostMapping
    public SavingAccount create(@RequestBody SavingAccount savingAccount) {
        return savingAccountService.save(savingAccount);
    }

    @PostMapping("deposit")
    public SavingAccount deposit(@RequestBody DepositInfo depositInfo) {
        return savingAccountService.deposit(depositInfo);
    }
}
