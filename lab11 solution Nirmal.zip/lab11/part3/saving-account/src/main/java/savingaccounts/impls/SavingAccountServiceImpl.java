package savingaccounts.impls;

import savingaccounts.SavingAccountService;
import savingaccounts.model.DepositInfo;
import savingaccounts.model.SavingAccount;
import savingaccounts.model.WithDrawInfo;
import savingaccounts.repository.SavingAccountRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SavingAccountServiceImpl implements SavingAccountService {
    private final SavingAccountRepository savingAccountRepo;

    public SavingAccountServiceImpl(SavingAccountRepository savingAccountRepo) {
        this.savingAccountRepo = savingAccountRepo;
    }

    @Override
    public List<SavingAccount> getAll() {
        return savingAccountRepo.findAll();
    }
    private SavingAccount getAccountById(String accountId) {
        Optional<SavingAccount> account = savingAccountRepo.findById(accountId);

        if (account.isEmpty())
            throw new RuntimeException("Invalid account ID given...");

        return account.get();
    }
    @Override
    public SavingAccount save(SavingAccount savingAccount) {
        return savingAccountRepo.save(savingAccount);
    }

    @Override
    public SavingAccount deposit(DepositInfo depositInfo) {

        SavingAccount account = getAccountById(depositInfo.getAccountId());
        account.setBalance(account.getBalance() + depositInfo.getAmount());

        return savingAccountRepo.save(account);
    }

    @Override
    public SavingAccount withdraw(WithDrawInfo withDrawInfo) {
        SavingAccount account = getAccountById(withDrawInfo.getAccountId());

        if (withDrawInfo.getAmount() > account.getBalance())
            throw new RuntimeException("insufficient balance");

        account.setBalance(account.getBalance() - withDrawInfo.getAmount());

        return savingAccountRepo.save(account);
    }
}
