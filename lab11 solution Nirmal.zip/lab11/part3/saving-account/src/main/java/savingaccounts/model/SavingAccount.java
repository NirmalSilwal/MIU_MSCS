package savingaccounts.model;


import lombok.*;

@ToString
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SavingAccount {
    private String id;
    private String name;
    private double balance;
}