package savingaccounts.repository;

import savingaccounts.model.SavingAccount;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SavingAccountRepository extends MongoRepository<SavingAccount, String> {
}
